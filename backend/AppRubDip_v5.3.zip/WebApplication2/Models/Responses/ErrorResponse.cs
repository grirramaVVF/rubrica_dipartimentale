﻿namespace ApiRubricaDipartimentale.Models.Responses
{
    public class ErrorResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}

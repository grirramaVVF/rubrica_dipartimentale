﻿namespace ApiRubricaDipartimentale.Models.Responses
{
    public class JsonResponse
    {
        public bool Success { get; set; }
        public string Data { get; set; }
    }
}
